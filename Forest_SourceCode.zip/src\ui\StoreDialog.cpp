#include "ui/StoreDialog.h"
#include "core/CoinManager.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QMessageBox>
#include <QGroupBox>

StoreDialog::StoreDialog(CoinManager& coinManager, QWidget* parent)
    : QDialog(parent)
{
    setWindowTitle(QStringLiteral("植物商城"));
    setMinimumWidth(350);

    auto* mainLayout = new QVBoxLayout(this);

    auto* balanceLabel = new QLabel(
        QStringLiteral("当前金币: %1").arg(coinManager.balance()));
    balanceLabel->setStyleSheet("font-size:16px; font-weight:bold; color:#FFD700; padding:8px;");
    mainLayout->addWidget(balanceLabel);

    QObject::connect(&coinManager, &CoinManager::sig_balanceChanged,
        this, [balanceLabel](uint32_t bal) {
            balanceLabel->setText(QStringLiteral("当前金币: %1").arg(bal));
        });

    struct { const char* name; uint32_t type; uint32_t cost; } items[] = {
        {"松树 (PineTree)", 1, 500},
        {"玫瑰 (Rose)",     2, 500},
        {"银杏树",          3, 1000},
        {"向日葵",          4, 1000},
        {"仙人掌",          5, 1500},
    };

    for (const auto& item : items) {
        auto* group = new QGroupBox;
        auto* layout = new QHBoxLayout(group);
        layout->addWidget(new QLabel(QString::fromUtf8(item.name)));
        layout->addStretch();
        auto* btn = new QPushButton(QStringLiteral("解锁 %1 金币").arg(item.cost));
        QObject::connect(btn, &QPushButton::clicked,
            this, [this, &coinManager, type = item.type, cost = item.cost]() {
                if (coinManager.spend(cost)) {
                    QMessageBox::information(this,
                        QStringLiteral("解锁成功"),
                        QStringLiteral("新植物已解锁！"));
                } else {
                    QMessageBox::warning(this,
                        QStringLiteral("金币不足"),
                        QStringLiteral("请先完成专注任务赚取金币。"));
                }
            });
        layout->addWidget(btn);
        mainLayout->addWidget(group);
    }

    auto* closeBtn = new QPushButton(QStringLiteral("关闭"));
    QObject::connect(closeBtn, &QPushButton::clicked, this, &QDialog::accept);
    mainLayout->addWidget(closeBtn);
}
