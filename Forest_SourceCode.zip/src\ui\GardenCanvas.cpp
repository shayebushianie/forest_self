#include "ui/GardenCanvas.h"
#include <QPainter>

GardenCanvas::GardenCanvas(QWidget* parent) : QWidget(parent)
{
    setMinimumSize(COLS * CELL_SIZE + 20, 200);
    initPixmapCache();
}

void GardenCanvas::initPixmapCache()
{
    for (uint32_t type = 0; type <= 3; ++type) {
        plantCache_[type] = QPixmap(CELL_SIZE, CELL_SIZE);
    }
}

void GardenCanvas::loadRecords(const std::vector<FocusRecord>& records)
{
    records_ = records;
    int rows = (static_cast<int>(records_.size()) + COLS - 1) / COLS;
    setMinimumHeight(qMax(200, rows * CELL_SIZE + 20));
    update();
}

void GardenCanvas::refresh()
{
    update();
}

QRect GardenCanvas::computeCellRect(uint32_t index) const
{
    int row = static_cast<int>(index) / COLS;
    int col = static_cast<int>(index) % COLS;
    int x = col * CELL_SIZE + 10;
    int y = row * CELL_SIZE + 10;
    return QRect(x, y, CELL_SIZE - 4, CELL_SIZE - 4);
}

void GardenCanvas::paintEvent(QPaintEvent*)
{
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);

    painter.fillRect(rect(), QColor(30, 30, 30));

    for (size_t i = 0; i < records_.size(); ++i) {
        const auto& rec = records_[i];
        QRect cell = computeCellRect(static_cast<uint32_t>(i));

        if (rec.status == 0) {
            painter.fillRect(cell, QColor(34, 139, 34));
        } else {
            painter.fillRect(cell, QColor(80, 80, 80));
        }

        painter.setPen(QPen(QColor(20, 20, 20), 1));
        painter.drawRect(cell);
        painter.setPen(Qt::white);
        painter.setFont(QFont("Segoe UI", 7));
        painter.drawText(cell, Qt::AlignBottom | Qt::AlignHCenter, QString::number(i));
    }
}
