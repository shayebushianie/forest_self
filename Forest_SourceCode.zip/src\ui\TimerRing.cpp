#include "ui/TimerRing.h"
#include <QPainter>
#include <QPainterPath>
#include <QtMath>

TimerRing::TimerRing(QWidget* parent) : QWidget(parent)
{
    setMinimumSize(200, 240);
}

void TimerRing::setProgress(int remainingSeconds, int totalSeconds)
{
    remainingSeconds_ = remainingSeconds;
    totalSeconds_ = totalSeconds;
    update();
}

void TimerRing::setQuote(const QString& quote)
{
    quote_ = quote;
    update();
}

void TimerRing::paintEvent(QPaintEvent*)
{
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);

    int side = qMin(width(), height() - 60);
    QRectF rect((width() - side) / 2.0, 10, side, side);
    float ratio = totalSeconds_ > 0
        ? static_cast<float>(remainingSeconds_) / totalSeconds_ : 0.0f;

    // 背景圆环
    painter.setPen(QPen(QColor(60, 60, 60), 12));
    painter.drawArc(rect, 90 * 16, -360 * 16);

    // 进度弧（颜色随剩余时间变化：绿→黄→红）
    QColor arcColor;
    if (ratio > 0.6f)      arcColor = QColor(76, 175, 80);
    else if (ratio > 0.3f) arcColor = QColor(255, 193, 7);
    else                    arcColor = QColor(244, 67, 54);

    painter.setPen(QPen(arcColor, 12));
    painter.drawArc(rect, 90 * 16, -static_cast<int>(360 * 16 * ratio));

    // 中心时间文字
    int mins = remainingSeconds_ / 60;
    int secs = remainingSeconds_ % 60;
    QString timeStr = QString("%1:%2").arg(mins, 2, 10, QChar('0')).arg(secs, 2, 10, QChar('0'));

    QFont timeFont("Segoe UI", 28, QFont::Bold);
    painter.setFont(timeFont);
    painter.setPen(Qt::white);
    painter.drawText(rect, Qt::AlignCenter, timeStr);

    // 底部自勉语录
    if (!quote_.isEmpty()) {
        QFont quoteFont("Microsoft YaHei", 11);
        painter.setFont(quoteFont);
        painter.setPen(QColor(180, 180, 180));
        QRectF quoteRect(0, side + 15, width(), 40);
        painter.drawText(quoteRect, Qt::AlignHCenter | Qt::AlignTop, quote_);
    }
}
