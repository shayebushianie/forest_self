#ifndef TIMERRING_H
#define TIMERRING_H

#include <QWidget>

class TimerRing : public QWidget {
    Q_OBJECT

public:
    explicit TimerRing(QWidget* parent = nullptr);

    void setProgress(int remainingSeconds, int totalSeconds);
    void setQuote(const QString& quote);

protected:
    void paintEvent(QPaintEvent* event) override;

private:
    int remainingSeconds_ = 0;
    int totalSeconds_ = 1;
    QString quote_;
};

#endif // TIMERRING_H
