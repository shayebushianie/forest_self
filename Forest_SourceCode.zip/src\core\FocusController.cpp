#include "core/FocusController.h"
#include "plant/OakTree.h"
#include "plant/PineTree.h"
#include "plant/Rose.h"
#include <ctime>
#include <iostream>

FocusController::FocusController(DatabaseManager& db, QObject* parent)
    : QObject(parent), db_(db)
{
}

void FocusController::startFocus(uint32_t plantType, uint32_t minutes)
{
    if (currentState_ != State::IDLE) return;
    if (minutes < 10 || minutes > 120) return;

    plannedMinutes_ = minutes;
    totalSeconds_ = minutes * 60;
    remainingSeconds_ = totalSeconds_;
    actualSeconds_ = 0;
    violationCount_ = 0;

    switch (plantType) {
    case 0: currentPlant_.reset(new OakTree()); break;
    case 1: currentPlant_.reset(new PineTree()); break;
    case 2: currentPlant_.reset(new Rose()); break;
    default: return;
    }

    FocusRecord record;
    record.plantType = plantType;
    record.plannedMinutes = minutes;
    record.status = 3; // RUNNING
    record.startTimestamp = static_cast<uint64_t>(std::time(nullptr));
    recordIndex_ = db_.append(record);

    currentState_ = State::RUNNING;
    emit sig_stateChanged(currentState_);
    std::cout << "[FocusController] Focus started: "
              << currentPlant_->getPlantName()
              << " for " << minutes << " minutes.\n";
}

void FocusController::pauseFocus()
{
    if (currentState_ != State::RUNNING) return;
    currentState_ = State::PAUSED;
    emit sig_stateChanged(currentState_);
    std::cout << "[FocusController] Focus paused.\n";
}

void FocusController::resumeFocus()
{
    if (currentState_ != State::PAUSED) return;
    currentState_ = State::RUNNING;
    emit sig_stateChanged(currentState_);
    std::cout << "[FocusController] Focus resumed.\n";
}

void FocusController::abandonFocus()
{
    if (currentState_ != State::RUNNING && currentState_ != State::PAUSED) return;

    if (currentPlant_) {
        currentPlant_->wither();
    }

    currentState_ = State::FAILED;
    emit sig_stateChanged(currentState_);

    FocusRecord record;
    record.recordId = recordIndex_;
    record.plantType = currentPlant_ ? currentPlant_->getPlantType() : 0;
    record.plannedMinutes = plannedMinutes_;
    record.actualSeconds = actualSeconds_;
    record.status = 2; // 中途放弃
    record.violationCount = violationCount_;
    record.growthStage = currentPlant_ ? currentPlant_->getGrowthStage() : 4;
    record.coinsEarned = 0;
    record.tagId = 0;
    db_.updateById(recordIndex_, record);

    std::cout << "[FocusController] Focus abandoned. Tree withered.\n";
}

void FocusController::triggerViolation(const QString& processName)
{
    if (currentState_ != State::RUNNING) return;

    ++violationCount_;
    std::cout << "[FocusController] VIOLATION #" << violationCount_
              << " detected: " << processName.toStdString() << "\n";

    handleFailure();
}

void FocusController::tick()
{
    if (currentState_ != State::RUNNING) return;

    --remainingSeconds_;
    ++actualSeconds_;

    updateGrowth();

    emit sig_tick(remainingSeconds_, actualSeconds_);

    if (remainingSeconds_ == 0) {
        handleSuccess();
    }
}

void FocusController::updateGrowth()
{
    if (!currentPlant_) return;
    currentPlant_->grow(static_cast<int>(actualSeconds_), static_cast<int>(totalSeconds_));
    emit sig_growthStageChanged(currentPlant_->getGrowthStage());
}

void FocusController::handleSuccess()
{
    currentState_ = State::SUCCESS;
    emit sig_stateChanged(currentState_);

    uint32_t coins = calculateCoins();
    uint32_t growthStage = currentPlant_ ? currentPlant_->getGrowthStage() : 3;

    FocusRecord record;
    record.recordId = recordIndex_;
    record.plantType = currentPlant_ ? currentPlant_->getPlantType() : 0;
    record.plannedMinutes = plannedMinutes_;
    record.actualSeconds = actualSeconds_;
    record.status = 0; // 成功
    record.violationCount = violationCount_;
    record.growthStage = growthStage;
    record.coinsEarned = coins;
    record.tagId = 0;
    db_.updateById(recordIndex_, record);

    std::cout << "[FocusController] Focus succeeded! "
              << currentPlant_->getPlantName()
              << " fully grown. Coins earned: " << coins << "\n";
}

void FocusController::handleFailure()
{
    if (currentPlant_) {
        currentPlant_->wither();
    }

    currentState_ = State::FAILED;
    emit sig_stateChanged(currentState_);

    FocusRecord record;
    record.recordId = recordIndex_;
    record.plantType = currentPlant_ ? currentPlant_->getPlantType() : 0;
    record.plannedMinutes = plannedMinutes_;
    record.actualSeconds = actualSeconds_;
    record.status = 1; // 违规失败
    record.violationCount = violationCount_;
    record.growthStage = 4; // 枯萎
    record.coinsEarned = 0;
    record.tagId = 0;
    db_.updateById(recordIndex_, record);

    std::cout << "[FocusController] Focus failed due to violation. Tree withered.\n";
}

uint32_t FocusController::calculateCoins() const
{
    return plannedMinutes_ / 5;
}
