#include <QApplication>
#include <QDir>
#include <QTimer>
#include <cstdlib>
#include <ctime>
#include "storage/DatabaseManager.h"
#include "core/FocusController.h"
#include "core/CoinManager.h"
#include "core/QuoteProvider.h"
#include "system/RuleEngine.h"
#include "system/SystemMonitor.h"
#include "ui/MainWindow.h"
#include "utils/Logger.h"

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);
    std::srand(static_cast<unsigned>(std::time(nullptr)));

    QString appDir = QApplication::applicationDirPath();

    Logger::instance().setLogPath(
        QDir(appDir).filePath("app.log").toStdString());
    Logger::instance().open();
    Logger::instance().info("Forest application started.");

    QString dbPath = QDir(appDir).filePath("sessions.dat");
    QString coinPath = QDir(appDir).filePath("coins.dat");

    DatabaseManager db(dbPath.toStdString());
    if (db.open()) {
        Logger::instance().info("Database opened: " + dbPath.toStdString()
            + " (" + std::to_string(db.count()) + " records)");
    } else {
        Logger::instance().error("Failed to open database: " + dbPath.toStdString());
    }

    CoinManager coinManager;
    coinManager.setDataPath(coinPath.toStdString());
    coinManager.load();
    Logger::instance().info("CoinManager loaded. Balance: "
        + std::to_string(coinManager.balance()));

    RuleEngine ruleEngine;
    ruleEngine.setBlacklist({"notepad.exe", "chrome.exe", "msedge.exe",
                              "steam.exe", "spotify.exe", "discord.exe"});
    Logger::instance().info("RuleEngine initialized with "
        + std::to_string(ruleEngine.blacklist().size()) + " blacklisted processes.");

    FocusController controller(db);
    SystemMonitor monitor(ruleEngine);
    QuoteProvider quotes;
    Logger::instance().info("Core components initialized.");

    QTimer focusTimer;
    QObject::connect(&focusTimer, &QTimer::timeout, [&]() { controller.tick(); });
    focusTimer.start(1000);

    MainWindow window(controller, monitor, ruleEngine, coinManager, quotes, db);
    window.show();
    Logger::instance().info("MainWindow displayed.");

    int ret = app.exec();

    Logger::instance().info("Forest application exiting.");
    db.close();
    Logger::instance().close();
    return ret;
}
