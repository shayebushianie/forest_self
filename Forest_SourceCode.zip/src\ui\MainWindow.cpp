#include "ui/MainWindow.h"
#include "ui/TimerRing.h"
#include "ui/GardenCanvas.h"
#include "ui/SettingsDialog.h"
#include "ui/StoreDialog.h"
#include "core/FocusController.h"
#include "core/CoinManager.h"
#include "core/QuoteProvider.h"
#include "system/RuleEngine.h"
#include "system/SystemMonitor.h"
#include "storage/DatabaseManager.h"

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QLabel>
#include <QMessageBox>
#include <QCloseEvent>
#include <QMenu>
#include <QApplication>
#include <QDir>
#include <QStyle>

MainWindow::MainWindow(FocusController& controller,
                       SystemMonitor& monitor,
                       RuleEngine& ruleEngine,
                       CoinManager& coinManager,
                       QuoteProvider& quotes,
                       DatabaseManager& db,
                       QWidget* parent)
    : QMainWindow(parent),
      controller_(controller), monitor_(monitor),
      ruleEngine_(ruleEngine), coinManager_(coinManager),
      quotes_(quotes), db_(db)
{
    setWindowTitle(QStringLiteral("Forest 专注森林"));
    setMinimumSize(620, 520);
    setStyleSheet("QMainWindow { background-color: #1e1e2e; }"
                  "QPushButton { background: #3a3a5c; color: white; border: none;"
                  "  padding: 8px 16px; border-radius: 6px; font-size: 13px; }"
                  "QPushButton:hover { background: #4a4a7c; }"
                  "QPushButton:disabled { background: #2a2a3c; color: #666; }"
                  "QLabel { color: #cdd6f4; }");

    auto* central = new QWidget;
    setCentralWidget(central);
    auto* mainLayout = new QVBoxLayout(central);

    timerRing_ = new TimerRing;
    mainLayout->addWidget(timerRing_, 1);

    auto* btnLayout = new QHBoxLayout;
    startBtn_   = new QPushButton(QStringLiteral("开始专注"));
    pauseBtn_   = new QPushButton(QStringLiteral("暂停"));
    abandonBtn_ = new QPushButton(QStringLiteral("放弃"));
    auto* settingsBtn = new QPushButton(QStringLiteral("设置"));
    auto* storeBtn    = new QPushButton(QStringLiteral("商城"));

    pauseBtn_->setEnabled(false);
    abandonBtn_->setEnabled(false);

    btnLayout->addWidget(startBtn_);
    btnLayout->addWidget(pauseBtn_);
    btnLayout->addWidget(abandonBtn_);
    btnLayout->addStretch();
    btnLayout->addWidget(settingsBtn);
    btnLayout->addWidget(storeBtn);
    mainLayout->addLayout(btnLayout);

    auto* gardenLabel = new QLabel(QStringLiteral("— 我的森林 —"));
    gardenLabel->setAlignment(Qt::AlignCenter);
    gardenLabel->setStyleSheet("font-size:14px; padding-top:8px; color:#a6adc8;");
    mainLayout->addWidget(gardenLabel);

    gardenCanvas_ = new GardenCanvas;
    mainLayout->addWidget(gardenCanvas_, 2);

    QObject::connect(startBtn_, &QPushButton::clicked, this, &MainWindow::onStartClicked);
    QObject::connect(pauseBtn_, &QPushButton::clicked, this, &MainWindow::onPauseResumeClicked);
    QObject::connect(abandonBtn_, &QPushButton::clicked, this, &MainWindow::onAbandonClicked);
    QObject::connect(settingsBtn, &QPushButton::clicked, this, &MainWindow::onSettingsClicked);
    QObject::connect(storeBtn, &QPushButton::clicked, this, &MainWindow::onStoreClicked);

    QObject::connect(&controller_, &FocusController::sig_tick,
        this, [this](uint32_t remaining, uint32_t) {
            timerRing_->setProgress(static_cast<int>(remaining), static_cast<int>(remaining + 1));
        });

    QObject::connect(&controller_, &FocusController::sig_stateChanged,
        this, [this](FocusController::State) { updateUI(); });

    QObject::connect(&controller_, &FocusController::sig_growthStageChanged,
        this, [this](uint32_t) { updateUI(); });

    QObject::connect(&monitor_, &SystemMonitor::sig_violationDetected,
        &controller_, &FocusController::triggerViolation);

    QObject::connect(&monitor_, &SystemMonitor::sig_violationDetected,
        this, [this](const QString& name) {
            QMessageBox::warning(this,
                QStringLiteral("违规警告"),
                QStringLiteral("检测到违规进程: %1\n专注已失败，小树枯萎了！").arg(name));
        });

    QObject::connect(&quoteTimer_, &QTimer::timeout, this, [this]() {
        timerRing_->setQuote(quotes_.getRandomQuote());
    });

    setupTrayIcon();
    refreshGarden();
    updateUI();
}

void MainWindow::closeEvent(QCloseEvent* event)
{
    if (controller_.currentState() == FocusController::State::RUNNING ||
        controller_.currentState() == FocusController::State::PAUSED) {
        auto result = QMessageBox::question(this,
            QStringLiteral("确认退出"),
            QStringLiteral("正在专注中！退出将会导致小树枯萎。\n确定要退出吗？"),
            QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
        if (result == QMessageBox::Yes) {
            controller_.abandonFocus();
            event->accept();
        } else {
            event->ignore();
        }
    } else {
        event->accept();
    }
}

void MainWindow::onStartClicked()
{
    SettingsDialog dlg(ruleEngine_, this);
    if (dlg.exec() != QDialog::Accepted) return;

    controller_.startFocus(dlg.selectedPlantType(), dlg.selectedMinutes());
    monitor_.startMonitoring();
    quoteTimer_.start(10000);
    timerRing_->setQuote(quotes_.getRandomQuote());
    updateUI();
}

void MainWindow::onPauseResumeClicked()
{
    if (controller_.currentState() == FocusController::State::RUNNING) {
        controller_.pauseFocus();
        monitor_.stopMonitoring();
        quoteTimer_.stop();
    } else if (controller_.currentState() == FocusController::State::PAUSED) {
        controller_.resumeFocus();
        monitor_.startMonitoring();
        quoteTimer_.start(10000);
    }
    updateUI();
}

void MainWindow::onAbandonClicked()
{
    auto result = QMessageBox::question(this,
        QStringLiteral("确认放弃"),
        QStringLiteral("放弃后小树会枯萎，确定吗？"),
        QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
    if (result == QMessageBox::Yes) {
        controller_.abandonFocus();
        monitor_.stopMonitoring();
        quoteTimer_.stop();
        updateUI();
        refreshGarden();
    }
}

void MainWindow::onSettingsClicked()
{
    SettingsDialog dlg(ruleEngine_, this);
    dlg.exec();
}

void MainWindow::onStoreClicked()
{
    StoreDialog dlg(coinManager_, this);
    dlg.exec();
}

void MainWindow::updateUI()
{
    auto state = controller_.currentState();
    bool running = (state == FocusController::State::RUNNING);
    bool paused  = (state == FocusController::State::PAUSED);
    bool idle    = (state == FocusController::State::IDLE ||
                    state == FocusController::State::SUCCESS ||
                    state == FocusController::State::FAILED);

    startBtn_->setEnabled(idle);
    pauseBtn_->setEnabled(running || paused);
    abandonBtn_->setEnabled(running || paused);

    if (running) {
        pauseBtn_->setText(QStringLiteral("暂停"));
    } else if (paused) {
        pauseBtn_->setText(QStringLiteral("继续"));
    }

    if (state == FocusController::State::SUCCESS) {
        uint32_t coins = controller_.actualSeconds() / 300;
        coinManager_.earn(coins);
        QMessageBox::information(this,
            QStringLiteral("恭喜！"),
            QStringLiteral("专注完成！你获得了 %1 枚金币！").arg(coins));
        monitor_.stopMonitoring();
        quoteTimer_.stop();
        refreshGarden();
    } else if (state == FocusController::State::FAILED) {
        monitor_.stopMonitoring();
        quoteTimer_.stop();
        refreshGarden();
    }
}

void MainWindow::refreshGarden()
{
    auto records = db_.getAllRecords();
    gardenCanvas_->loadRecords(records);
}

void MainWindow::setupTrayIcon()
{
    trayIcon_ = new QSystemTrayIcon(
        QApplication::style()->standardIcon(QStyle::SP_ComputerIcon), this);
    trayIcon_->setToolTip(QStringLiteral("Forest 专注森林"));

    auto* menu = new QMenu;
    menu->addAction(QStringLiteral("显示主窗口"), this, &QWidget::show);
    menu->addAction(QStringLiteral("退出"), qApp, &QApplication::quit);
    trayIcon_->setContextMenu(menu);

    QObject::connect(trayIcon_, &QSystemTrayIcon::activated,
        this, &MainWindow::onTrayActivated);

    trayIcon_->show();
}

void MainWindow::onTrayActivated(QSystemTrayIcon::ActivationReason reason)
{
    if (reason == QSystemTrayIcon::DoubleClick) {
        show();
        raise();
        activateWindow();
    }
}
