#ifndef COINMANAGER_H
#define COINMANAGER_H

#include <QObject>
#include <cstdint>
#include <fstream>
#include <string>

class CoinManager : public QObject {
    Q_OBJECT

public:
    explicit CoinManager(QObject* parent = nullptr);
    ~CoinManager() override;

    void setDataPath(const std::string& path);
    bool load();
    bool save();

    uint32_t balance() const { return balance_; }
    bool earn(uint32_t amount);
    bool spend(uint32_t amount);

signals:
    void sig_balanceChanged(uint32_t newBalance);

private:
    std::string dataPath_;
    uint32_t balance_ = 0;
};

#endif // COINMANAGER_H
