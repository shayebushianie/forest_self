#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSystemTrayIcon>
#include <QTimer>
#include <QPushButton>
#include <memory>

class FocusController;
class SystemMonitor;
class RuleEngine;
class CoinManager;
class QuoteProvider;
class DatabaseManager;
class TimerRing;
class GardenCanvas;
class SettingsDialog;

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(FocusController& controller,
                        SystemMonitor& monitor,
                        RuleEngine& ruleEngine,
                        CoinManager& coinManager,
                        QuoteProvider& quotes,
                        DatabaseManager& db,
                        QWidget* parent = nullptr);

protected:
    void closeEvent(QCloseEvent* event) override;

private slots:
    void onStartClicked();
    void onPauseResumeClicked();
    void onAbandonClicked();
    void onSettingsClicked();
    void onStoreClicked();
    void onTrayActivated(QSystemTrayIcon::ActivationReason reason);

private:
    void updateUI();
    void refreshGarden();
    void setupTrayIcon();

    FocusController& controller_;
    SystemMonitor& monitor_;
    RuleEngine& ruleEngine_;
    CoinManager& coinManager_;
    QuoteProvider& quotes_;
    DatabaseManager& db_;

    TimerRing* timerRing_;
    GardenCanvas* gardenCanvas_;
    QPushButton *startBtn_, *pauseBtn_, *abandonBtn_;
    QSystemTrayIcon* trayIcon_;
    QTimer quoteTimer_;
};

#endif // MAINWINDOW_H
