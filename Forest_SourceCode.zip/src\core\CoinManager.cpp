#include "core/CoinManager.h"
#include <iostream>

CoinManager::CoinManager(QObject* parent) : QObject(parent) {}
CoinManager::~CoinManager() { save(); }

void CoinManager::setDataPath(const std::string& path) { dataPath_ = path; }

bool CoinManager::load()
{
    std::ifstream file(dataPath_, std::ios::binary);
    if (!file.is_open()) { balance_ = 0; return true; }
    file.read(reinterpret_cast<char*>(&balance_), sizeof(balance_));
    return file.good() || file.eof();
}

bool CoinManager::save()
{
    std::ofstream file(dataPath_, std::ios::binary | std::ios::trunc);
    if (!file.is_open()) return false;
    file.write(reinterpret_cast<const char*>(&balance_), sizeof(balance_));
    return file.good();
}

bool CoinManager::earn(uint32_t amount)
{
    balance_ += amount;
    save();
    emit sig_balanceChanged(balance_);
    std::cout << "[CoinManager] Earned " << amount << " coins. Balance: " << balance_ << "\n";
    return true;
}

bool CoinManager::spend(uint32_t amount)
{
    if (amount > balance_) return false;
    balance_ -= amount;
    save();
    emit sig_balanceChanged(balance_);
    std::cout << "[CoinManager] Spent " << amount << " coins. Balance: " << balance_ << "\n";
    return true;
}
