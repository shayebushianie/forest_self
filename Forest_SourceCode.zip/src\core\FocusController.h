#ifndef FOCUSCONTROLLER_H
#define FOCUSCONTROLLER_H

#include <QObject>
#include <memory>
#include <cstdint>
#include "plant/AbstractPlant.h"
#include "storage/DatabaseManager.h"

class FocusController : public QObject {
    Q_OBJECT

public:
    enum class State : uint32_t {
        IDLE = 0,
        RUNNING = 1,
        PAUSED = 2,
        SUCCESS = 3,
        FAILED = 4
    };

    explicit FocusController(DatabaseManager& db, QObject* parent = nullptr);
    ~FocusController() override = default;

    void startFocus(uint32_t plantType, uint32_t minutes);
    void pauseFocus();
    void resumeFocus();
    void abandonFocus();
    void triggerViolation(const QString& processName);
    void tick();

    State currentState() const { return currentState_; }
    uint32_t remainingSeconds() const { return remainingSeconds_; }
    uint32_t actualSeconds() const { return actualSeconds_; }
    uint32_t violationCount() const { return violationCount_; }

signals:
    void sig_stateChanged(FocusController::State newState);
    void sig_tick(uint32_t remainingSeconds, uint32_t actualSeconds);
    void sig_growthStageChanged(uint32_t stage);

private:
    void handleSuccess();
    void handleFailure();
    void updateGrowth();
    uint32_t calculateCoins() const;

    State currentState_ = State::IDLE;
    uint32_t plannedMinutes_ = 0;
    uint32_t totalSeconds_ = 0;
    uint32_t remainingSeconds_ = 0;
    uint32_t actualSeconds_ = 0;
    uint32_t violationCount_ = 0;
    uint32_t recordIndex_ = 0;

    std::unique_ptr<AbstractPlant> currentPlant_;
    DatabaseManager& db_;
};

#endif // FOCUSCONTROLLER_H
